<!-- BEGIN: Main Menu-->
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
      <div class="navbar-header">
       <center><img src="<?php echo base_url(); ?>assets/images/logo/GFA-Logo.png" align="center"></center>
		
    </div><br> <br> <br>
      <div class="shadow-bottom"></div>
      <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
         <li class=" navigation-header"><span data-i18n="Apps &amp; Pages">Quick Menu</span><i data-feather="more-horizontal"></i>
		 
		  <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Dashboard</span></a>
            <ul class="menu-content">
		
			</ul>
          </li>
		 
		 <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Cohort</span></a>
            <ul class="menu-content">
		
			</ul>
          </li>
		 
		   <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Application</span></a>
            <ul class="menu-content">
            </ul>
          </li>
		  
		   <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Mentors</span></a>
            <ul class="menu-content">
             
            </ul>
          </li>
		  
		   <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Investors</span></a>
            <ul class="menu-content">
            
            </ul>
          </li>
		  
		   <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Perks</span></a>
            <ul class="menu-content">
              
            </ul>
          </li>
		   <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Digital Services</span></a>
           
          </li>
		   <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Digital Products</span></a>
            <ul class="menu-content">
		
			</ul>
          </li>
		  <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Corporate Partners</span></a>
           
          </li>
		  
		   <li class=" nav-item active"  style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Manage Events</span></a>
            <ul class="menu-content">
             
            </ul>
          </li>
		    <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Media & PR</span></a>
           
          </li>
		  
		   <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Report & Metrics</span></a>
            <ul class="menu-content">
            
            </ul>
          </li>
		  
		<li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Hiring</span></a>
           
          </li>
		  
		   <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Forms & Surveys</span></a>
           
          </li>
		  
		   <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Community</span></a>
           
          </li>
          <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Content</span></a>
           
          </li>
          <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Learning</span></a>
           
          </li>
          <li class=" nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="comiingsoon">
		   <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Entertainment</span></a>
           
          </li>
         
          
        </ul>
      </div>
    </div>
    <!-- END: Main Menu-->

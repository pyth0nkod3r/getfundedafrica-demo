<?php 
  $this->gfa_model = model('App\Models\GfaModel');
  $this->admin_model = model('App\Models\AdminModel');
   ?>
    <!-- BEGIN: Main Menu-->
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
      <div class="navbar-header">
       <center><a href="<?php echo base_url('gfa/dashboard'); ?>"><img src="<?php echo base_url('public/assets/images/logo/GFA-Logo.png'); ?>" align="center"></a></center>
        
    </div><br> <br> <br>
      <div class="shadow-bottom"></div>
      <div class="main-menu-content">
          <?php 
                
                // $loginkey = $this->gfa_model->getWpCred($email);
                // $rowArray = $this->admin_model->getAllStartUpNByEmail($email);
           ?>
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
         <li class=" navigation-header"><span data-i18n="Apps &amp; Pages">GFA Solutions</span><i data-feather="more-horizontal"></i>
         
         <?php   
          if(!empty($login_type)){  ?>
 
         <li class=" nav-item active"  style="margin-top:10px;"><a class="d-flex align-items-center" href="<?php echo base_url(); ?>admin/event">
           <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Admin Dashboard</span></a>
            
          </li>
          <li class="nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="#">
           <i data-feather="settings"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Perks</span></a>
            <ul class="menu-content">
            <li><a class="d-flex align-items-center" href="<?php echo base_url('gfa/add_perks'); ?>" alt="Add Perks"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Analytics">+ Add Perks</span></a></li>
              <li><a class="d-flex align-items-center" href="<?php echo base_url('gfa/manage_perks'); ?>" alt="Manage Perks"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Analytics">Manage Perks</span></a></li>
              <li><a class="d-flex align-items-center" href="<?php echo base_url('gfa/manage_perks_category'); ?>"  alt="Manage Category"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="eCommerce">Perks Category</span></a></li>
              <li><a class="d-flex align-items-center" href="<?php echo base_url('gfa/perks_redeemed'); ?>" alt="Perks Redeemed"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="eCommerce">Redeemed</span></a></li>
             </ul>
          </li>
         <?php }else{   ?>
      <li class=" nav-item active"  style="margin-top:10px;"><a class="d-flex align-items-center" href="<?php echo base_url('gfa/dashboard'); ?>">
           <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Dashboard</span></a>
       </li>
       <li class=" nav-item active"  style="margin-top:10px;"><a class="d-flex align-items-center" href="<?php echo base_url('gfa/resource'); ?>">
           <i data-feather="file"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Resource</span></a>
       </li>
          <li class=" nav-item active"  style="margin-top:10px;"><a class="d-flex align-items-center" href="<?php echo base_url('calendar/index'); ?>">
           <i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Schedule a Meeting</span></a>
       </li>
       </li>
          <li class=" nav-item active"  style="margin-top:10px;"><a class="d-flex align-items-center" href="<?php echo base_url('chat/index'); ?>">
           <i data-feather="speaker"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Chat</span></a>
       </li>
       </li>
          <li class=" nav-item active"  style="margin-top:10px;"><a class="d-flex align-items-center" href="<?php echo base_url('gfa/notify_inbox'); ?>">
           <i data-feather="users"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Messaging</span></a>
       </li>
       <li class=" nav-item active"  style="margin-top:10px;"><a class="d-flex align-items-center" href="<?php echo base_url('gfa/subscribe'); ?>">
           <i data-feather="user"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Subscription</span></a>
       </li>
       

          
          
          <li class=" nav-item active"  style="margin-top:10px;">
              
               <?php //if(!empty($this->gfa_model->getCurrentSub($email,'Basic Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Premium Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Business Funding','active')) ){  ?>
    
     <?php //if($this->gfa_model->creditPointScore($email) >=50)  {  ?>
 <a class="d-flex align-items-center" href="<?php echo base_url('gfa/dealroom'); ?>">
  <?php   //}else{  ?>
     <!--<a href="#" data-bs-target="#checkDealRoomProfile" data-bs-toggle="modal"> -->
     <!--<a href="#" data-bs-target="#checkDealRoom" data-bs-toggle="modal">-->
   <?php  //}  ?>
    
    
  <?php   //}else{  ?>
  
 
 <!--<a href="#" data-bs-target="#checkDealRoom" data-bs-toggle="modal">       -->
 
         
          
 <?php   // }
     
     ?>
              
              
           
           <i data-feather="layers"></i><span class="menu-title text-truncate" data-i18n="Data and Insight">Dealroom<?php //echo  ?></span></a>
            
          </li>
         
         <li class="nav-item active" style="margin-top:10px;"><a class="d-flex align-items-center" href="#">
           <i data-feather="settings"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Account Settings</span></a>
            <ul class="menu-content">
              
              <li><a class="d-flex align-items-center" href="<?php echo base_url('gfa/profile'); ?>" alt="Update Profile"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Analytics">Profile</span></a></li>
              <li><a class="d-flex align-items-center" href="<?php echo base_url('gfa/change_password'); ?>"  alt="Update Password"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="eCommerce">Change Password</span></a></li>
              <li><a class="d-flex align-items-center" href="<?php echo base_url('gfa/billing'); ?>" alt="Billing"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="eCommerce">Billing</span></a></li>
             </ul>
          </li>
           
          </li>
          <li class=" nav-item active"  style="margin-top:10px;"><a class="d-flex align-items-center" href="<?php echo base_url('gfa/signoutAction'); ?>">
           <i data-feather="power"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Logout</span></a>
       </li>
         
          
         
           <!--<li class=" nav-item active"  style="margin-top:10px;"><a class="d-flex align-items-center" href="https://events.getfundedafrica.com" target="_blank">-->
           <!--<i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Events</span></a>-->
            
          </li>
          
          
            
         
          <?php }  ?>
        </ul>
      </div>
    </div>
    <!-- END: Main Menu-->
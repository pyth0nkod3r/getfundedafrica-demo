    <!-- BEGIN: Content-->
    <div class="app-content content ">
      <div class="content-overlay"></div>
      <div class="header-navbar-shadow"></div>
      <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
            <?php 
		         
		        $loginkey = $this->gfa_model->getWpCred($email);
		   ?>
        <div class="content-body"><!-- Dashboard Analytics Start -->
<section id="dashboard-analytics">
  <div class="row match-height">
    <!-- Greetings Card starts -->
    <div class="col-lg-6 col-md-12 col-sm-12">
      <div class="card card-congratulations">
        <div class="card-body text-center">
          <img
            src="../../../app-assets/images/elements/decore-left.png"
            class="congratulations-img-left"
            alt="card-img-left"
          />
          <img
            src="../../../app-assets/images/elements/decore-right.png"
            class="congratulations-img-right"
            alt="card-img-right"
          />
          <div class="avatar avatar-xl bg-primary shadow">
            <div class="avatar-content">
              <i data-feather="award" class="font-large-1"></i>
            </div>
          </div>
          <div class="text-center">
            <h1 class="mb-1 text-white">Congratulations</h1>
            <p class="card-text m-auto w-15">
              You have done <strong><?php echo $point ?>%</strong> onboarding. <br><a href="<?php echo base_url(); ?>gfa/profile" style="color:#fff;" target="_blank">Pls update your profile for better experience, click here.</a>
            </p>
            
       
      <?php 
    
    $startupPaid = $this->gfa_model->getPaidSubscriber($email); 
    
    ?>
      <b>
          <?php if(!empty($this->gfa_model->getCurrentSub($email,'Basic Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Premium Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Business Funding','active')) ){ ?>
          You have an active subscription from <?php foreach($startupPaid as $startupPaidArray){  ?>
          <?php  echo date('d M, y',strtotime($startupPaidArray['time_start']));  ?> to <?php  echo date('d M, y',strtotime($startupPaidArray['time_end']));  ?>
            <?php }}else{ ?>
            <a href="<?php echo base_url(); ?>gfa/subscribe" title="Subscription" ? style="color:#fff;">No active subscription found, click here to activate.</a>
            <?php }  ?>
            </b>
           
        
        
            
          </div>
        </div>
      </div>
    </div>
    <!-- Greetings Card ends -->

    <!-- Subscribers Chart Card starts -->
	
 <div class="col-lg-3 col-sm-6 col-12">
      <div class="card">
          
          
    <?php 
    
    $startupPaid = $this->gfa_model->getPaidSubscriber($email); 
    
    //if($startupPaid[0]['payment_status']=='paid' && $startupPaid[0]['status']=='active' && $point >=50 ) {
    // if(!empty($this->gfa_model->getCurrentSub($email,'Basic Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Premium Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Business Funding','active'))){ 
    ?>
     
       
       
           
   
    
    
    
   <?php  if($point < 50){ ?>
    
    
    <a href="#" data-bs-target="#checkProfile" data-bs-toggle="modal"> 
    
    
    <?php }else{ ?>
    
      <a href="<?php echo base_url(); ?>gfa/startup_investor"> 
    
  <?php   }
    ?>
    
    <?php //} else { ?>
     <!--<a href="<?php echo base_url(); ?>gfa/startup_investor"> -->
    
   
 <?php //}   ?>
   
    <div class="card-header flex-column align-items-start pb-0">
          <div class="avatar bg-light-primary p-50 m-0">
            <div class="avatar-content">
              <i data-feather="users" class="font-medium-5"></i>
            </div>
          </div>
          <h2 class="fw-bolder mt-1"><p class="card-text">&nbsp;<br>
          <?php
          
            
            $account_type= $this->encrypt->decode($this->session->userdata('account_type'));
          if($account_type=='startup' || $account_type=='' || $account_type=='individual' ){
          $rowArray = $this->admin_model->getAllStartUpNByEmail($email);
          echo $this->admin_model->countMatchInvestorDefaultApp($rowArray[0]['PrimaryBusinessIndustry'],$rowArray[0]['CurrentInvestmentStage'],$rowArray[0]['Startup_Implementation_Stage'],$rowArray[0]['Next_Funding_Round_Target_Sought'],$rowArray[0]['OperatingRegions']); ?>
          <br>Investors Match</p> </h2>
         <?php }elseif($account_type=='investor') { 
         $rowArrayInv = $this->admin_model->getAllInvestorNByEmail($email);
         echo $this->admin_model->countMatchStartupDefault($rowArrayInv[0]['Industry_Focus'],$rowArrayInv[0]['Investment_Stage_Focus'],$rowArrayInv[0]['Implementation_Stage_Focus'],$this->admin_model->getCountryByRegion($rowArrayInv[0]['Regional_focus'])[0]['country'],$rowArrayInv[0]['Min_Cheque']);
         ?>
             
            <p class="card-text">Startups Match</p> 
       <?php   }else{ echo 0;   ?> 
        
         <p class="card-text">No Match<br><br><span class="badge badge-light-warning me-1">[Update Your Profile]</span></p> 
       <?php   }  ?>
       
       
        </div>
        <div id="gained-chart"></div>
		</a>
      </div>
    </div>
	
    <!-- Subscribers Chart Card ends -->

    <!-- Orders Chart Card starts -->
    <div class="col-lg-3 col-sm-6 col-12">
      <div class="card">
         <a href="#" data-bs-target="#editUser" data-bs-toggle="modal">
        <div class="card-header flex-column align-items-start pb-0">
          <div class="avatar bg-light-warning p-50 m-0">
            <div class="avatar-content">
              <i data-feather="package" class="font-medium-5"></i>
            </div>
          </div>
          <?php if($this->admin_model->getCreditRedeemByEmail($email)[0]['More_Info'] !='' && $this->admin_model->getCreditRedeemSumByEmail($email)==60){ ?>
          <h2 class="fw-bolder mt-1"><?php detectCurrency(); ?><?php echo 0 ; ?></h2>
            <?php }elseif($this->admin_model->getCreditRedeemByEmail($email)[0]['More_Info'] !='' && $this->admin_model->getCreditRedeemSumByEmail($email)==15){ 
            
            if(!empty($this->gfa_model->getCurrentSub($email,'Basic Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Premium Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Business Funding','active'))){
            ?>
            
           <h2 class="fw-bolder mt-1"><?php detectCurrency(); ?><?php echo  detectCurrencyAmount($balanceCredit); ?></h2> 
           <?php  }else{  ?>
           <h2 class="fw-bolder mt-1"><?php detectCurrency(); ?><?php echo detectCurrencyAmount($balanceCreditFree); ?></h2>
          <?php } ?>
           
          <p class="card-text">Free e-store credit redeemed!</p>
         <?php }else{  ?>
          <h2 class="fw-bolder mt-1"><?php detectCurrency(); ?><?php echo detectCurrencyAmount($viewcredit); ?></h2>
          <p class="card-text">Free e-store credit</p>
          <?php } ?>
        </div>
        <div id="order-chart"></div>
        </a>
      </div>
    </div>
    <!-- Orders Chart Card ends -->
  </div>

  
  
  
  
  
   <div class="row match-height">
    <div class="col-lg-12 col-12">
      <div class="row match-height">
          
        <!-- Bar Chart - Orders -->
        <div class="col-lg-3 col-md-3 col-6">
            <?php     // if($startupPaid[0]['payment_status']=='paid' && $startupPaid[0]['status']=='active'  ) {  ?>
     <?php if(!empty($this->gfa_model->getCurrentSub($email,'Basic Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Premium Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Business Funding','active')) ){ 
    if($rowArray[0]['CountryHQ'] =='' && $rowArray[0]['PrimaryBusinessIndustry'] =='')  {
        $url = base_url()."gfa/profile";
    }else{
     $url = base_url()."gfa/hire";   
    }
    
    
     }else{
         
        $url = base_url()."gfa/subscribe"; 
     }
    
    ?>
            <a href="<?php echo $url; ?>">
          <div class="card">
            <div class="card-body pb-50">
                 <h3 class="fw-bolder mb-1">Hiring</h3>
              <h6><?php echo  $this->admin_model->countMatchCandidateApp($rowArray[0]['CountryHQ'],$rowArray[0]['PrimaryBusinessIndustry']) ?></h6>
             
              <div class="avatar-content avatar  p-50 m-0 bg-light-primary" style="float:right;">
              <i data-feather="user-check" class="font-large-2"  style="color:#7A6FF1;"></i>
         
            </div>
            </div>
          </div></a>
        </div>
        <!--/ Bar Chart - Orders -->

         <!-- Bar Chart - Orders -->
        <div class="col-lg-3 col-md-3 col-6">
            <a href="<?php echo base_url(); ?>gfa/comingsoon" tartget="GFA Max">
          <div class="card">
            <div class="card-body pb-50">
                 <h3 class="fw-bolder mb-1">Entertainment</h3>
              <h6>20</h6>
            
             
              <div class="avatar-content avatar p-50 m-0 bg-light-primary" style="float:right;">
              <i data-feather="film" class="font-large-2"  style="color:#7A6FF1;"></i>
         
            </div>
            </div>
          </div></a>
        </div>
        <!--/ Bar Chart - Orders -->
        
           <!-- Bar Chart - Orders -->
        <div class="col-lg-3 col-md-3 col-6">
     <?php     // if($startupPaid[0]['payment_status']=='paid' && $startupPaid[0]['status']=='active'  ) {  ?>
     <?php //if(!empty($this->gfa_model->getCurrentSub($email,'Basic Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Premium Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Business Funding','active')) ){ 
    if($rowArray[0]['Mentorship'] =='')  { 
     //$url = base_url()."gfa/profile";
    ?>
       
        <a href="#" data-bs-target="#checkMentorProfile" data-bs-toggle="modal"> 
 <?php    }else{ 
 //$url = base_url()."gfa/startup_mentor"; 
 
 ?>
    <a href="<?php echo base_url(); ?>gfa/startup_mentor">   
 <?php    }  
    
    
     //}else{
         
        //$url = base_url()."gfa/startup_mentor"; 
     //}
    
    ?>
           
           
                
          <div class="card">
            <div class="card-body pb-50">
                 <h3 class="fw-bolder mb-1">Mentors</h3>
              <h6>  <?php 
          echo $this->admin_model->countMatchMentorDefaultApp($rowArray[0]['PrimaryBusinessIndustry'],$rowArray[0]['Mentorship'],$rowArray[0]['Startup_Implementation_Stage']); ?></h6>
             
              <div class="avatar-content avatar  p-50 m-0 bg-light-primary" style="float:right;">
              <i data-feather="users" class="font-large-2"  style="color:#7A6FF1;"></i>
         
            </div>
            </div>
          </div></a>
        </div>
        
        
        
        <!--/ Bar Chart - Orders -->
        
  <!-- Bar Chart - Orders -->
        <div class="col-lg-3 col-md-3 col-6">
             <?php // if(!empty($this->gfa_model->getCurrentSub($email,'Basic Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Premium Funding','active')) || !empty($this->gfa_model->getCurrentSub($email,'Business Funding','active')) ){ 
    if($point < 50) {
       $urly = base_url()."gfa/profile";
     }else{
     $urly = base_url()."gfa/startup_cooperate";   
     }
    
    
    //  }else{
         
    //     $urly = base_url()."gfa/startup_cooperate"; 
    //  }
    
    ?>
           
           
                <a href="<?php echo base_url(); ?>gfa/comingsoon<?php// echo $urly; ?>">
          <div class="card">
            <div class="card-body pb-50">
                 <h3 class="fw-bolder mb-1">Corporate</h3>
              <h6><?php 
              
              echo $this->admin_model->countMatchCooperateDefaultApp($rowArray[0]['CountryHQ']);
              
            //   $rowArray[0]['PrimaryBusinessIndustry'],$rowArray[0]['Startup_Implementation_Stage'],
              
              ?></h6>
             
              <div class="avatar-content avatar  p-50 m-0 bg-light-primary" style="float:right;">
              <i data-feather="briefcase" class="font-large-2"  style="color:#7A6FF1;"></i>
         
            </div>
            </div>
          </div></a>
        </div>
        <!--/ Bar Chart - Orders -->
          
          <!-- Bar Chart - Orders -->
        <div class="col-lg-3 col-md-3 col-6">
            <a href="<?php echo base_url(); ?>gfa/comingsoon">
          <div class="card">
            <div class="card-body pb-50">
                 <h3 class="fw-bolder mb-1">Find an Expert</h3>
              <h6>45</h6>
             
              <div class="avatar-content avatar  p-50 m-0 bg-light-primary" style="float:right;">
              <i data-feather="award" class="font-large-2"  style="color:#7A6FF1;"></i>
         
            </div>
            </div>
          </div></a>
        </div>
        <!--/ Bar Chart - Orders -->
          <!-- Bar Chart - Orders -->
        <div class="col-lg-3 col-md-3 col-6">
            <a href="<?php echo base_url(); ?>gfa/comingsoon">
          <div class="card">
            <div class="card-body pb-50">
                 <h3 class="fw-bolder mb-1">Workspace</h3>
              <h6>400</h6>
             
              <div class="avatar-content avatar  p-50 m-0 bg-light-primary" style="float:right;">
              <i data-feather="layers" class="font-large-2"  style="color:#7A6FF1;"></i>
         
            </div>
            </div>
          </div></a>
        </div>
        <!--/ Bar Chart - Orders -->
        
          <!-- Bar Chart - Orders -->
        <div class="col-lg-3 col-md-3 col-6">
            <a href="<?php echo base_url(); ?>gfa/comingsoon">
          <div class="card">
            <div class="card-body pb-50">
                 <h3 class="fw-bolder mb-1">Data & Insight</h3>
              <h6>15</h6>
             
              <div class="avatar-content avatar  p-50 m-0 bg-light-primary" style="float:right;">
              <i data-feather="activity" class="font-large-2"  style="color:#7A6FF1;"></i>
         
            </div>
            </div>
          </div></a>
        </div>
        <!--/ Bar Chart - Orders -->
        
        
          <!-- Bar Chart - Orders -->
        <div class="col-lg-3 col-md-3 col-6">
            <a href="https://remsana.getfundedafrica.com/sso.php?key=<?php echo $loginkey[0][LoginKey]; ?>" target="_blank">
          <div class="card">
            <div class="card-body pb-50">
                 <h3 class="fw-bolder mb-1">Learning</h3>
              <h6>76</h6>
             
              <div class="avatar-content avatar  p-50 m-0 bg-light-primary" style="float:right;">
              <i data-feather="book-open" class="font-large-2"  style="color:#7A6FF1;"></i>
         
            </div>
            </div>
          </div>
          </a>
        </div>
        <!--/ Bar Chart - Orders -->
        

      </div>
    </div>
  
  
 <!-- Timeline Card -->
    <div class="col-lg-4 col-12">
      <div class="card card-user-timeline">
        <div class="card-header">
          <div class="d-flex align-items-center">
            <i data-feather="list" class="user-timeline-title-icon"></i>
            <h4 class="card-title"><a href="<?php echo base_url(); ?>gfa/comingsoon">Tell your Story</a></h4>
          </div>
        </div>
        <div class="card-body">
          <ul class="timeline ms-50">
              
              
          
            <li class="timeline-item">
              <span class="timeline-point timeline-point-indicator"></span>
              <div class="timeline-event">
                <a href="<?php echo base_url(); ?>gfa/comingsoon">
				<h6>Microsoft funding </h6>
                <p>10,000 African startups to benefit</p>
                <div class="d-flex align-items-center">
                  <img class="me-1" src="../../../app-assets/images/icons/json.png" alt="data.json" height="23" />
                
                </div>
				</a>
              </div>
            </li>

            <li class="timeline-item">
              <span class="timeline-point timeline-point-info timeline-point-indicator"></span>
              <div class="timeline-event">
                <a href="<?php echo base_url(); ?>gfa/comingsoon"><h6>Featured Story </h6>
                <p>Some of the great founders stories we have told the world</p>
                <div class="avatar-group">
                
                  <div
                    data-bs-toggle="tooltip"
                    data-popup="tooltip-custom"
                    data-bs-placement="bottom"
                    title="Amy Carson"
                    class="avatar pull-up"
                  >
                    <img
                      src="../../../app-assets/images/portrait/small/avatar-s-6.jpg"
                      alt="Avatar"
                      width="33"
                      height="33"
                    />
                  </div>
                  <div
                    data-bs-toggle="tooltip"
                    data-popup="tooltip-custom"
                    data-bs-placement="bottom"
                    title="Brandon Miles"
                    class="avatar pull-up"
                  >
                    <img
                      src="../../../app-assets/images/portrait/small/avatar-s-8.jpg"
                      alt="Avatar"
                      width="33"
                      height="33"
                    />
                  </div>
                  
                </div>
              </a>
			  </div>
            </li>
       
          </ul>
        </div>
      </div>
    </div>
    <!--/ Timeline Card -->

  

  <!-- Profile Card -->
  <div class="col-lg-4 col-md-6 col-12">
    <div class="card card-profile">
      <img
        src="https://getfundedafrica.com/images/cohort.jpg"
        class="img-fluid card-img-top"
        alt="Profile Cover Photo"
      />
      <?php $rowArray = $this->admin_model->getAllCohortEvent();
      $cohortReg = $this->admin_model->getAllCohort();
      ?>
      <div class="card-body">
        <div class="profile-image-wrapper">
          <div class="profile-image">
            <div class="avatar">
               
              <img src="<?php echo base_url(); ?>uploads/<?php echo $rowArray[0]['Banner'] ?>" alt="Cohort Picture" />
            </div>
          </div>
        </div>
         
        <h6 class="text-muted">NEXT COHORT STARTING</h6>
         <?php if(!empty($cohortReg))  { ?>
        <br>
       	
        <h3>Investor Readiness<?php //echo $rowArray[0]['Cohort_Type'] ?> Cohort</h3>
        <br>
        <span class="badge badge-light-primary profile-badge"> <?php echo date('jS M Y', strtotime('1/09/2023')) ?></span><br><br>
        
        
         <button onclick="document.location='https://getfundedafrica.com/cohort'" type="button" class="btn btn-primary" style="float:auto;">Learn more</button> 
      <!-- <?php }  ?>
       	<br>
       		<br>
         <?//php if(!empty($rowArray))  { ?>
       
        <h3><?//php echo $rowArray[0]['Title'] ?> Cohort</h3>
       
        <span class="badge badge-light-primary profile-badge"> <?//php echo date('jS M Y', strtotime($rowArray[0]['Date'])) ?></span><br><br>
        
        
         <button onclick="document.location='<?//php echo $rowArray[0]['Url'] ?>'" type="button" class="btn btn-primary" style="float:auto;">Learn more</button> 
       <?//php }  ?>
       -->
       
      </div>
    </div>
  </div>
  <!--/ Profile Card -->
  
  
  <!-- Developer Meetup Card -->
  <div class="col-lg-4 col-md-6 col-12">
    <div class="card card-developer-meetup">
      <div class="meetup-img-wrapper rounded-top text-center">
        <img src="https://pixinvent.com/demo/vuexy-html-bootstrap-admin-template/app-assets/images/illustration/email.svg" alt="Meeting Pic" height="170" />
      </div>
      
      <?php //foreach($eventResp as $eventResponseArray){  ?>
      <div class="card-body">
        <div class="meetup-header d-flex align-items-center">
          <div class="meetup-day">
            <h6 class="mb-0"><?php $dateEvent = date('w', strtotime($eventResp['Date']));
            echo $this->gfa_model->getDay($dateEvent);  ?>
            </h6>
            <h3 class="mb-0"><?php echo date('d', strtotime($eventResp['Date']));  ?></h3>
          </div>
          <div class="my-auto">
            <h4 class="card-title mb-25">GetFundedAfrica Events </h4>
            <p class="card-text mb-0"><?php echo $eventResp['Title']; ?></p>
            <p><a href="<?php echo $eventResp['Url']; ?>" target="_blank">Click here for more info</a></p>
          </div>
        </div>
        <div class="d-flex flex-row meetings">
          <div class="avatar bg-light-primary rounded me-1">
            <div class="avatar-content">
              <i data-feather="calendar" class="avatar-icon font-medium-3"></i>
            </div>
          </div>
          <div class="content-body">
            <h6 class="mb-0"><?php echo date('M d, Y', strtotime($eventResp['Date'])) ?></h6>
            <small><?php echo str_replace("-", "to", $eventResp['Time']) ?></small>
          </div>
        </div>
        <div class="d-flex flex-row meetings">
          <div class="avatar bg-light-primary rounded me-1">
            <div class="avatar-content">
              <i data-feather="map-pin" class="avatar-icon font-medium-3"></i>
            </div>
          </div>
          <div class="content-body">
            <h6 class="mb-0"><?php echo $eventResp['Location']; ?></h6>
            <!--<small>Abeokuta, Ogun State</small>-->
          </div>
        </div>
        <input type="hidden" class="eventId" value="<?php echo $eventResp['ID']; ?>" >
         <input type="hidden" class="title" value="<?php echo $eventResp['Title']; ?>" >
         <?php if($this->gfa_model->getWpEvent($email)[0]['status']=='active'){  ?>
          <div class="avatar-content avatar  p-50 m-0 bg-light-primary" style="float:right;">
              <i data-feather="user-check" class="font-large-2"  style="color:#7A6FF1;"></i>
         
            </div>
           <?php }elseif($this->gfa_model->getWpEvent($email)[0]['status']=='pending'){  ?> 
           <button type="button" disabled class="btn btn-primary attendEvent">Enquiry Pending</button>
           <?php }else{  ?>
            <button type="button" class="btn btn-primary attendEvent">Attend Event</button>
           <?php } ?>
            </div>
            <!--onclick="location.href='https://events.getfundedafrica.com';"-->
            <?php// }  ?>
    </div>
  </div>
  <!--/ Developer Meetup Card -->
  

  

</section>
<!-- Dashboard Analytics end -->

<div class="modal fade" id="editUser" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-edit-user">
    <div class="modal-content">
      <div class="modal-header bg-transparent">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body pb-5 px-sm-5 pt-50">
        <div class="text-center mb-2">
         <span><i data-feather="info" class="font-large-2 me-sm-2 mb-2 mb-sm-0"></i></span><h1 class="mb-1">Credit redemption</h1>
          <p><a href="http://estore.getfundedafrica.com/sso.php?key=<?php echo $loginkey[0][LoginKey]; ?>" target="_blank">Go to our e-store for investor readiness templates</a></p>
             <!--<input type="text" class="credit" value="<?php //echo $this->admin_model->getCreditAciveSub($email) ?>" >-->
            <input type="hidden" class="credit" value="<?php echo $showCredit ?>" > 
           <?php if($showCredit >=15 ){  ?>
          <!--<p>Go to our estore to redeem your credit, use the discount code below at the checkout to cliam your credit.</p>-->
          <?php if($this->admin_model->getCreditRedeemByEmail($email)[0]['More_Info'] !=''){  ?>
         
          <p><strong><?php echo $this->admin_model->getCreditRedeemByEmail($email)[0]['More_Info'] ?></strong> </p>
          <?php }  ?>
          <?php }else{  ?>
          
          <p> You can not redeem your credit until you have minimum of <?php detectCurrency(); ?><?php echo detectCurrencyAmount(10500); ?>. Please update your profile to aleast 50% and earn more free credit.</p>
          
         
          <?php }  ?>
         
        </div>
      
         <?php if($showCredit >=15 ){  ?>
       
      
      <?php
       
      ?>
     
        <!--<button  class="btn btn-primary float-end mt-3" disabled>-->
        <!--  <span class="me-50">Credit Request Pending</span>-->
        <!--  <i data-feather="box"></i>-->
        <!--</button>-->
     
        
        
       <?php 
        //}
      // } else{  ?>
       
       <!--<button  class="btn btn-primary float-end mt-3" disabled>-->
       <!--   <span class="me-50">Credit Request Pending</span>-->
       <!--   <i data-feather="box"></i>-->
       <!-- </button>-->
        
        <?php  //}   ?>
        
       <?php if (empty($this->admin_model->getCreditRedeemByEmail($email)[0]['Credit'])) { ?>
    
           <button  class="btn btn-primary mt-3 RedeemCredit">
          <span class="me-50 displayRedeem">Click here to redeem your e-store credit</span>
          <i data-feather="box"></i>
        </button>
     <?php       }else{ 
          if($showCredit !=''){
              
           if($showCredit ==0){ echo ''; }else{  
        ?>
        
        <button  class="btn btn-primary float-end mt-3 RedeemCredit" disabled >
          <span class="me-50 displayRedeem">Credit waiting for activation</span>
          <i data-feather="box"></i>
        </button>
      <?php  } } } ?>
      
     
      
    <?php  } else{  ?>
    
    <a href="<?php echo base_url(); ?>gfa/profile" class="btn btn-primary float-end mt-3" >
          <span class="me-50">Update Profile</span>
          <i data-feather="user"></i>
        </a>
    <?php  //}else{  ?>
    
    
    <?php //}  ?>
        
   <?php  }  //}  ?>
      </div>
      
    </div>
  </div>
</div>

<div class="modal fade" id="checkProfile" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-edit-user">
    <div class="modal-content">
      <div class="modal-header bg-transparent">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body pb-5 px-sm-5 pt-50">
        <div class="text-center mb-2">
         <span><i data-feather="info" class="font-large-2 me-sm-2 mb-2 mb-sm-0"></i></span><h1 class="mb-1">Profile Completion</h1>
          <!--<p><a href="http://estore.getfundedafrica.com/sso.php?key=<?php //echo $loginkey[0][LoginKey]; ?>" target="_blank">Click here to visit estore</a></p>-->
        <p>
            <!--Kindly update your profile at least more than 50% for better investor match.-->
            Your profile update is <?php echo $point ?>%, pls update it to aleast 50% to view list of matched investors.
        </p>
        
        <br>
       
        <a href="<?php echo base_url(); ?>gfa/profile" class="btn btn-primary float-end mt-3" >
          <span class="me-50">Update Profile</span>
          <i data-feather="user"></i>
        </a>
     
     
      </div>
      
    </div>
  </div>
</div>


        </div>
        
        <div class="modal fade" id="checkMentorProfile" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-edit-user">
    <div class="modal-content">
      <div class="modal-header bg-transparent">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body pb-5 px-sm-5 pt-50">
        <div class="text-center mb-2">
         <span><i data-feather="info" class="font-large-2 me-sm-2 mb-2 mb-sm-0"></i></span><h1 class="mb-1">Profile Completion</h1>
          <!--<p><a href="http://estore.getfundedafrica.com/sso.php?key=<?php //echo $loginkey[0][LoginKey]; ?>" target="_blank">Click here to visit estore</a></p>-->
        <p>
             Your profile update is <?php echo $point ?>%, pls update it to aleast 50% to view list of matched mentors.
        </p>
        
        <br>
       
        <a href="<?php echo base_url(); ?>gfa/profile" class="btn btn-primary float-end mt-3" >
          <span class="me-50">Update Profile</span>
          <i data-feather="user"></i>
        </a>
     
     
      </div>
      
    </div>
  </div>
</div>


        </div>
      </div>
    </div>
    <!-- END: Content-->

<script>
    $(function(){
        
        
         $(".attendEvent").click(function(){
         
         var  eventId = $('.eventId').val();
         var  title = $('.title').val();
          $.ajax({
     data:{eventId:eventId,title:title},
     type: "POST",
     url: "<?php echo base_url(); ?>gfa/attendEvent",
     error:function() {$(".attendEvent").html('Error Request');},
	 beforeSend:function() {$(".attendEvent").html('Requesting...');$('.attendEvent').prop("disabled", true );},
      success: function(data) {
       
		 $(".attendEvent").html('Enquiry Pending'); 
	    $('.attendEvent').prop("disabled", true );
	   
	  
	
       }
      
    });
         
       }); 
       
       $(".RedeemCredit").click(function(){
         
         var  credit = $('.credit').val();
          $.ajax({
     data:{credit:credit},
     type: "POST",
     url: "<?php echo base_url(); ?>gfa/creditRedeem",
     error:function() {$(".displayRedeem").html('Error Request');},
	 beforeSend:function() {$(".displayRedeem").html('Requesting...');},
      success: function(data) {
       
		  
		 $(".displayRedeem").html('Request Pending'); 
	    $('.RedeemCredit').prop("disabled", true );
	   
	  
	
       }
      
    });
         
       }); 
        
    });
</script>
   
  
    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

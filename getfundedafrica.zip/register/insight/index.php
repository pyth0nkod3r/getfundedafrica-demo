<?php
$url = 'https://getfundedafrica.com/register/?ref=insight';
header('location:'.$url.'');
exit();

?>
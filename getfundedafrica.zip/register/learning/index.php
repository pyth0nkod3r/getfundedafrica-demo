<?php
$url = 'https://getfundedafrica.com/register/?ref=learning';
header('location:'.$url.'');
exit();

?>
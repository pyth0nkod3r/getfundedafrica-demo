<?php
$url = 'https://getfundedafrica.com/register/?ref=news';
header('location:'.$url.'');
exit();

?>
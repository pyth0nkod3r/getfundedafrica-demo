<?php
$url = 'https://getfundedafrica.com/register/?ref=investors';
header('location:'.$url.'');
exit();

?>
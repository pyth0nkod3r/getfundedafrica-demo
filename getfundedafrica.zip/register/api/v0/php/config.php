<?php
    class Config 
    {
        public static $databaseName = "getfylig_trans";
        public static $databaseUsername = "NoraDBAdmin";
        public static $databasePassword = "Creo*la@1789";
        public static $host = "noradb.mysql.database.azure.com";
    }	
?>
<?php
$url = 'https://getfundedafrica.com/register/?ref=funding';
header('location:'.$url.'');
exit();

?>
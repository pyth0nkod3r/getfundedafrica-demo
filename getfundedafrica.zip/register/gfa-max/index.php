<?php
$url = 'https://getfundedafrica.com/register/?ref=gfa-max';
header('location:'.$url.'');
exit();

?>
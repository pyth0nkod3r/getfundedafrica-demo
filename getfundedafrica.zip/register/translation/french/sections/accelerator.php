<?php

$accelerator = [
    'incubator' => [
        'head' => 'Quel type de startups incubez-vous / accélérez-vous ? ',
        'wrapper-1' => [
            'block-1' => [
                'head' => 'Petites entreprises au stade précoce ou tardif',
                'sub' => '',
            ],
            'block-2' => [
                'head' => 'Entreprise de démarrage précoce finançable',
                'sub' => '',
            ],
            'block-3' => [
                'head' => 'Entreprise de démarrage tardif finançable',
                'sub' => '',
            ],
            'block-4' => [
                'head' => 'Petites et moyennes entreprises de tous les stades',
                'sub' => '',
            ],
            'block-5' => [
                'head' => 'Stade spécifique Autres entreprises',
                'sub' => '',
            ],
        ],
    ],
];

?>

<?php

    $individual = [
        'individual' => [
            'wrapper-1' => [
                'head' => 'Quel est votre intérêt ? Sélectionnez une option qui applicable. Recevoir :',
                'block-1' => [
                    'head' => 'Des mises à jour ',
                    'sub' => 'Recevoir les dernières nouvelles sur les startups',
                ],
                'block-2' => [
                    'head' => 'Collecte de fonds ',
                    'sub' => 'Lever des fonds pour votre entreprise ',
                ],
                'block-3' => [
                    'head' => 'Croissance de l`entreprise ',
                    'sub' => 'Obtenir les outils pour développer votre entreprise ',
                ],
                'block-4' => [
                    'head' => 'Rapport instructif  ',
                    'sub' => 'Rester à jour des rapports de marché ',
                ],
                'block-5' => [
                    'head' => 'Apprentissage',
                    'sub' => 'Apprendre à développer votre entreprise rapidement ',
                ],
                'block-6' => [
                    'head' => 'Diffusion',
                    'sub' => 'Regarder du contenu de qualité proposé par des startups ',
                ],
            ],
            'form-1' => [
                'head' => 'Abonnez-vous à notre newsletter',
                'name' => 'Nom complet',
                'email' => 'Email',
                'submit' => 'Soumettre'
            ],
            'form-2' => [
                'head' => '',
                'name' => 'Nom complet',
                'email' => 'Email',
                'mobile' => 'Mobile',
                'location' => 'Situation géographique',
                'city' => 'Ville',
                'submit' => 'Soumettre'
            ],
            'form-3' => [
                'head' => '',
                'name' => 'Nom complet',
                'email' => 'Email',
                'mobile' => 'Mobile',
                'location' => 'Situation géographique',
                'city' => 'Ville',
                'submit' => 'Soumettre'
            ],
            'form-4' => [
                'head' => '',
                'name' => 'Nom complet',
                'email' => 'Email',
                'mobile' => 'Mobile',
                'location' => 'Situation géographique',
                'city' => 'Ville',
                'submit' => 'Soumettre'
            ],
            'form-5' => [
                'head' => '',
                'name' => 'Nom complet',
                'email' => 'Email',
                'mobile' => 'Mobile',
                'location' => 'Situation géographique',
                'city' => 'Ville',
                'submit' => 'Soumettre'
            ],
            'form-6' => [
                'head' => '',
                'name' => 'Nom complet',
                'email' => 'Email',
                'mobile' => 'Mobile',
                'location' => 'Situation géographique',
                'city' => 'Ville',
                'submit' => 'Soumettre'
            ],
        ]
        
    ]

?>
<?php
$url = 'https://getfundedafrica.com/register/?ref=operations';
header('location:'.$url.'');
exit();

?>
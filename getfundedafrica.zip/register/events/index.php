<?php
$url = 'https://getfundedafrica.com/register/?ref=events';
header('location:'.$url.'');
exit();

?>
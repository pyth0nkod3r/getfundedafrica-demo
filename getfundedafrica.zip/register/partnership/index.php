<?php
$url = 'https://getfundedafrica.com/register/?ref=venture-building';
header('location:'.$url.'');
exit();

?>